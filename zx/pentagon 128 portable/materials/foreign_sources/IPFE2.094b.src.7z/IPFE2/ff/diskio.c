#include "diskio.h"
#include "sdio_stm32f1.h"
#include <string.h>

SD_CardInfo SDCardInfo;

/* FatFs Glue */
extern SD_Error Status;
SD_CardStatus SDCardStatus;
static volatile DSTATUS Stat = STA_NOINIT;	/* Disk status */
static volatile uint32_t Timer1, Timer2;	/* 100Hz decrement timers */

/**************************************************************************/
/*!
    Public Functions For FatFs.
*/
/**************************************************************************/
/**************************************************************************/
/*!
    @brief Initialize a Drive.
	@param  drv     : Physical drive number (0..).
    @retval DSTATUS :
*/
/**************************************************************************/
DSTATUS disk_initialize(uint8_t drv)
{
	switch (drv)
	{
		case SDIO_DRIVE:
		{
			/* Initialize SD Card */
			Status = SD_Init();
			if (Status != SD_OK)
				return STA_NOINIT;
			else
				return 0x00;
		}
  }
  return STA_NOINIT;
}

/**************************************************************************/
/*!
    @brief Return Disk Status.
	@param  drv     : Physical drive number (0..).
    @retval DSTATUS :
*/
/**************************************************************************/
DSTATUS disk_status(uint8_t drv)
{
	switch (drv)
	{
		case SDIO_DRIVE:
		{
			Status = SD_GetCardInfo(&SDCardInfo);

			if (Status != SD_OK)
				return STA_NOINIT;
			else
				return 0x00;
		}
	}
	return STA_NOINIT;
}

/**************************************************************************/
/*!
    @brief Read Sector(s).
	@param  drv     : Physical drive number (0..).
	@param  *buff   : Data buffer to store read data.
	@param  sector  : Sector address (LBA).
	@param  count   : Number of sectors to read.
    @retval DSTATUS :
*/
/**************************************************************************/
DRESULT disk_read(BYTE drv, BYTE *buff, DWORD sector, UINT count)
{
	switch (drv)
	{
		case SDIO_DRIVE:
		{
			SD_Error status;
			if ( count == 1 )
				status = SD_ReadBlock( (uint8_t*)(buff), ((uint64_t)(sector)*SECTOR_SIZE), SECTOR_SIZE );
			else
				status = SD_ReadMultiBlocks( (uint8_t*)(buff), ((uint64_t)(sector)*SECTOR_SIZE), SECTOR_SIZE, count );
			status = SD_WaitReadOperation();
			while( SD_GetStatus() != SD_TRANSFER_OK )	;
			if ( status == SD_OK )	return RES_OK;
			else					return RES_ERROR;
		}
	}
	return RES_PARERR;
}

/**************************************************************************/
/*!
    @brief Write Sector(s).
	@param  drv     : Physical drive number (0..).
	@param  *buff   : Data to be written.
	@param  sector  : Sector address (LBA).
	@param  count   : Number of sectors to write.
    @retval DSTATUS :
*/
/**************************************************************************/
#if _READONLY == 0
DRESULT disk_write( BYTE drv, const BYTE *buff, DWORD sector, UINT count)
{
	switch (drv)
	{
		case SDIO_DRIVE:
		{
			SD_Error status;

			if ( count == 1 )
				status = SD_WriteBlock( (uint8_t*)(buff), ((uint64_t)(sector)*SECTOR_SIZE), SECTOR_SIZE );
			else
				status = SD_WriteMultiBlocks( (uint8_t*)(buff), ((uint64_t)(sector)*SECTOR_SIZE), SECTOR_SIZE, count );
		    status = SD_WaitWriteOperation();
		    while( SD_GetStatus() != SD_TRANSFER_OK )	;
			if ( status == SD_OK )	return RES_OK;
			else					return RES_ERROR;
		}
	}
	return RES_PARERR;
}
#endif /* _READONLY */

/**************************************************************************/
/*!
    @brief Miscellaneous Functions.
	@param  drv     : Physical drive number (0..).
	@param  ctrl    : Control code.
	@param  *buff   : Buffer to send/receive control data.
    @retval DSTATUS :
*/
/**************************************************************************/
DRESULT disk_ioctl(uint8_t drv,uint8_t ctrl,void *buff)
{
	switch (drv)
	{
		case SDIO_DRIVE:
		{
		  switch (ctrl)
		  {
			case CTRL_SYNC:
			  /* no synchronization to do since not buffering in this module */
			  return RES_OK;
			case GET_SECTOR_SIZE:
			  *(uint16_t*)buff = SECTOR_SIZE;
			  return RES_OK;
			case GET_SECTOR_COUNT:
			  *(uint32_t*)buff = SDCardInfo.CardCapacity / SECTOR_SIZE;
			  return RES_OK;
			case GET_BLOCK_SIZE:
			  *(uint32_t*)buff = SDCardInfo.CardBlockSize;
			  return RES_OK;
			/* Following command are not used by FatFs module */
			case MMC_GET_TYPE :		/* Get MMC/SDC type (uint8_t) */
				*(uint8_t*)buff = SDCardInfo.CardType;
				return RES_OK;
			case MMC_GET_CSD :		/* Read CSD (16 bytes) */
				memcpy((void *)buff,&SDCardInfo.SD_csd,16);
				return RES_OK;
			case MMC_GET_CID :		/* Read CID (16 bytes) */
				memcpy((void *)buff,&SDCardInfo.SD_cid,16);
				return RES_OK;
			case MMC_GET_OCR :		/* Read OCR (4 bytes) */
				*(uint32_t*)buff = SDCardInfo.SD_csd.MaxRdCurrentVDDMin;
				return RES_OK;
			case MMC_GET_SDSTAT :	/* Read SD status (64 bytes) */
				SD_GetCardStatus(&SDCardStatus);
				memcpy((void *)buff,&SDCardStatus,64);
				return RES_OK;
			default :
				return RES_OK;
			}
		}
	}
	return RES_PARERR;
}


/**************************************************************************/
/*!
    @brief Device Timer Interrupt Procedure.							@n
		   This function must be called in period of 10ms.
	@param  none
    @retval none
*/
/**************************************************************************/
/* Not used On STM32Primer2 */
#if !defined(USE_STM32PRIMER2)
void disk_timerproc (void)
{
	uint8_t n, s;

	n = Timer1;					/* 100Hz decrement timer */
	if (n) Timer1 = --n;
	n = Timer2;
	if (n) Timer2 = --n;


	s = Stat;
	if (SOCKWP)					/* WP is H (write protected) */
		s |= STA_PROTECT;
	else						/* WP is L (write enabled) */
		s &= ~STA_PROTECT;

	if (!SD_Detect())			/* INS = H (Socket empty) */
		s |= (STA_NODISK | STA_NOINIT);
	else						/* INS = L (Card inserted) */
		s &= ~STA_NODISK;
	Stat = s;
}
#endif
