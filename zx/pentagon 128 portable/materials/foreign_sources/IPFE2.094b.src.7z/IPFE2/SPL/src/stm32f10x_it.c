/* IPFE Floppy Emulator 2014-2015 IanPo(zx-pk.ru) */

#include "stm32f10x_it.h"
#include "sdio_stm32f1.h"
#include "fe.h"
#include "lcd-hd44780.h"
#include "hw_config.h"
#include "usb_lib.h"
#include "usb_istr.h"
#include "usb_pwr.h"

/* Private variables ---------------------------------------------------------*/
extern uint8_t buff[];
extern uint32_t track_lengs[];
extern volatile long int CurrBit;
volatile uint16_t ZeroCounter;
extern volatile uint32_t CylNumber;
extern volatile uint32_t LoadedCylNumber;
extern volatile long int CurrBitW, CurrBitWStart;
extern volatile long int SideW;
extern volatile uint16_t mfm_NOC;
//
volatile long int LocalByte, LocalByteW;
volatile char LocalBit, LocalBitW;
//
extern volatile FE_States CurrState;
//
extern	uint8_t LCDbuff[];
//
uint32_t temp_s;
uint16_t temp_e2;
long int temp_e3;

volatile uint16_t ECounter = 0x0000;
volatile uint32_t LCDPointer = 0;
extern volatile uint32_t ReqStop, AckStop;

/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

/******************************************************************************/
/*            Cortex-M3 Processor Exceptions Handlers                         */
/******************************************************************************/

/**
  * @brief  This function handles NMI exception.
  * @param  None
  * @retval None
  */
void NMI_Handler(void)
{
#ifdef TRACE
	xprintf("NMI");
#endif
}

/**
  * @brief  This function handles Hard Fault exception.
  * @param  None
  * @retval None
  */
void HardFault_Handler(void)
{
  /* Go to infinite loop when Hard Fault exception occurs */
#ifdef TRACE
	xprintf("HardFault");
#endif

  while (1)
  {
  }
}

/**
  * @brief  This function handles Memory Manage exception.
  * @param  None
  * @retval None
  */
void MemManage_Handler(void)
{
#ifdef TRACE
	xprintf("MemMgr");
#endif

  /* Go to infinite loop when Memory Manage exception occurs */
  while (1)
  {
  }
}

/**
  * @brief  This function handles Bus Fault exception.
  * @param  None
  * @retval None
  */
void BusFault_Handler(void)
{
#ifdef TRACE
	xprintf("BusFault");
#endif

  /* Go to infinite loop when Bus Fault exception occurs */
  while (1)
  {
  }
}

/**
  * @brief  This function handles Usage Fault exception.
  * @param  None
  * @retval None
  */
void UsageFault_Handler(void)
{
#ifdef TRACE
	xprintf("UsageFault");
#endif

  /* Go to infinite loop when Usage Fault exception occurs */
  while (1)
  {
  }
}

/**
  * @brief  This function handles SVCall exception.
  * @param  None
  * @retval None
  */
void SVC_Handler(void)
{
#ifdef TRACE
	xprintf("SVC");
#endif

}

/**
  * @brief  This function handles Debug Monitor exception.
  * @param  None
  * @retval None
  */
void DebugMon_Handler(void)
{
#ifdef TRACE
	xprintf("DbgMon");
#endif

}

/**
  * @brief  This function handles PendSV_Handler exception.
  * @param  None
  * @retval None
  */
void PendSV_Handler(void)
{
#ifdef TRACE
	xprintf("PendSV");
#endif

}

/**
  * @brief  This function handles SysTick Handler.
  * @param  None
  * @retval None
  */
void SysTick_Handler(void)
{
}

/*******************************************************************************
* Function Name  : USB_HP_CAN1_TX_IRQHandler
* Description    : This function handles USB High Priority or CAN TX interrupts requests
*                  requests.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void USB_HP_CAN1_TX_IRQHandler(void)
{
  CTR_HP();
}

/*******************************************************************************
* Function Name  : USB_IRQHandler
* Description    : This function handles USB Low Priority interrupts
*                  requests.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void USB_LP_CAN1_RX0_IRQHandler(void)
{
  USB_Istr();
}

/**************************************************************************/
/*!
    @brief	Handles SDIO interrupts requests.
	@param	None.
    @retval	None.
*/
/**************************************************************************/
void SDIO_IRQHandler(void)
{
	/* Process All SDIO Interrupt Sources */
	SD_ProcessIRQSrc();
}

void SD_SDIO_DMA_IRQHANDLER(void)
{
	SD_ProcessDMAIRQ();
}

/*******************************************************************************
* Function Name  : USB_FS_WKUP_IRQHandler
* Description    : This function handles USB WakeUp interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void USBWakeUp_IRQHandler(void)
{
	EXTI->PR = EXTI_Line18;
}


/***********************************************************************/
/*                 STM32F4xx Peripherals Interrupt Handlers                   */
/*  Add here the Interrupt Handler for the used peripheral(s) (PPP), for the  */
/*  available peripheral interrupt handler's name please refer to the startup */
/*  file (startup_stm32f4xx.s).                                               */
/***********************************************************************/
void TIM8_UP_IRQHandler(void)
{
	TIM8->SR = 0;
	temp_s = ( pSIDE->IDR & FE_SIDE ) == 0;
	if ( CurrState == WRITETR )
	{
		LocalByte = CurrBit >> 3;
		CurrBit += 2;
		if ( CurrBit >= track_lengs[ 2 * LoadedCylNumber + ( SideW > 0 ) ] << 3 )	CurrBit = 0;
	}
	else
	{
		ZeroCounter = 7;
		while (1)
		{
			if ( CurrBit >= track_lengs[ 2 * LoadedCylNumber + temp_s ] << 3 )	CurrBit = 0;
			LocalByte = CurrBit >> 3;
			LocalBit = ~CurrBit++ & 7;
			if ( ( buff[ MAX_TRACK_LEN * temp_s + LocalByte ] >> LocalBit & 1 ) == 0 )	ZeroCounter += 8;
			else
				{
					TIM8->ARR = ZeroCounter;
					break;
				}
		}
	}
	//
	if ( LocalByte > INDEX_STOP )
		pINDEX->BSRR = FE_INDEX;	// High
	else
		if ( LocalByte >= INDEX_START )
			pINDEX->BRR = FE_INDEX;	// Low
}

void TIM8_CC_IRQHandler(void)
{
	TIM8->SR = 0;
	if ( CurrBitW < MAX_TRACK_LEN << 3 )
	{
		switch ( TIM8->CCR1 >> 5 )
		{
			case 3:
				buff[ CurrBitW >> 3 ] &= ~( 1 << (~CurrBitW++ & 7) );
			case 2:
				buff[ CurrBitW >> 3 ] &= ~( 1 << (~CurrBitW++ & 7) );
			case 1:
				buff[ CurrBitW >> 3 ] &= ~( 1 << (~CurrBitW++ & 7) );
			default:
			{
				buff[ CurrBitW >> 3 ] |= 1 << (~CurrBitW++ & 7);
				break;
			}
		}
	}
}

void TIM4_IRQHandler(void)
{
	TIM4->SR = 0;
	if ( CurrBitW < MAX_TRACK_LEN << 3 )
	{
		switch ( TIM4->CCR1 >> 5 )
		{
			case 3:
				buff[ (CurrBitW >> 3) + SideW ] &= ~( 1 << (~CurrBitW++ & 7) );
			case 2:
				buff[ (CurrBitW >> 3) + SideW ] &= ~( 1 << (~CurrBitW++ & 7) );
			case 1:
				buff[ (CurrBitW >> 3) + SideW ] &= ~( 1 << (~CurrBitW++ & 7) );
			default:
			{
				buff[ (CurrBitW >> 3) + SideW ] |= 1 << (~CurrBitW++ & 7);
				break;
			}
		}
	}
}

void EXTI15_10_IRQHandler(void)
{
	temp_e2 = pDS_M->IDR;
	temp_e3 = ( CurrBit - 12 ) & ~15;

//pREADY->BSRR = FE_READY;

	if ( EXTI->PR & EXTI_Line14 )
	{
		if ( CurrState == READTR )	// WGATE
		{
			CurrState = WRITETR;
			//
			if ( temp_e3 > 0 )
			{
				CurrBitW = temp_e3;
				CurrBitWStart = temp_e3;
			}
			else
			{
				CurrBitW = 0;
				CurrBitWStart = 0;
			}
			//			// Reset TIM4 counter
//			TIM4 -> PSC = 4;
//			TIM4 -> CNT = 0;							// �������� ������� �������� ��������
//			TIM4 -> EGR = TIM_EGR_UG | TIM_EGR_CC1G;		// ���������� ������� ����������
			// ��������� ����� ������� TIM8 �� ����� PC6
			GPIOC->CRL = 0x47444444;	// 50MHz OD
			// TIM8 4 us period
			TIM8->ARR = 15;
			// Disable EXTI Line 13 (step)
//			EXTI->IMR &= ~EXTI_Line13;
			//
			if ( pSIDE->IDR & FE_SIDE )
				SideW = 0;
			else
				SideW = MAX_TRACK_LEN;
			//
			LCDbuff[7] = (uint8_t)('W');
		}
		// Clear the EXTI line 14 pending bit
		EXTI->PR = EXTI_Line14;
	}
	if( EXTI->PR & EXTI_Line13 )	// STEP
	{
		if ( ( temp_e2 & FE_DS ) == 0 )
		{
			if ( temp_e2 & FE_DIR )	// To cyl0
			{
				if ( CylNumber > 0 )	CylNumber--;
				if ( CylNumber == 0 )
					pTR00->BRR = FE_TR00;	// Low
				else
					pTR00->BSRR = FE_TR00;	// High
			}
			else					// To the center of a disk
				if ( CylNumber < mfm_NOC )	CylNumber++;
		}
		/* Clear the EXTI Line 13 pending bit */
		EXTI->PR = EXTI_Line13;
	}
//pREADY->BRR = FE_READY;
}

void TIM3_IRQHandler(void)
{
	TIM3->SR = 0;
	//
	if ( AckStop == 0 )
	{
		switch ( ECounter++ )
		{
			case 0:
				if ( LCDPointer & 0x01 )
					lcd44780_port->BSRR = lcd44780_pin_RS;
				else
					lcd44780_port->BRR = lcd44780_pin_RS;
				lcd44780_port->BSRR = ( LCDbuff[ LCDPointer ] & 0xF0 ) << ( lcd44780_offset - 4 );
				break;
			case 1:
				lcd44780_port->BSRR = lcd44780_pin_E;
				break;
			case 2:
				lcd44780_port->BRR = lcd44780_pin_E;
				break;
			case 3:
				lcd44780_port->BRR = lcd44780_pins_data;
				break;
			case 4:
				lcd44780_port->BSRR = ( LCDbuff[ LCDPointer ] & 0x0F ) << lcd44780_offset;
				break;
			case 5:
				lcd44780_port->BSRR = lcd44780_pin_E;
				break;
			case 6:
				lcd44780_port->BRR = lcd44780_pin_E;
				break;
			case 7:
				lcd44780_port->BRR = lcd44780_pin_RS | lcd44780_pins_data;
				if ( ++LCDPointer >= LCDbuffLEN )	LCDPointer = 0;
				ECounter = 0;
				if ( ReqStop == 1 )
				{
					ReqStop = 0;
					AckStop = 1;
				}
				break;
		}
	}
}
/******************* (C) COPYRIGHT 2011 STMicroelectronics *****END OF FILE****/
