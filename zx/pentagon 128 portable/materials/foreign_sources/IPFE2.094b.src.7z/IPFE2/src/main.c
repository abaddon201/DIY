/* IPFE Floppy Emulator 2014-2016 IanPo(zx-pk.ru) */

#include <string.h>

#include "stm32f10x_conf.h"
#include "lcd-hd44780.h"
#include "sdio_stm32f1.h"
#include "xprintf.h"
#include "ff.h"
#include "fe.h"
#include "hw_config.h"
#include "usb_lib.h"
#include "usb_pwr.h"

#define VERSION "v0.094b"

// Private variables
FATFS filesystem;		/* volume lable */
FRESULT ret;			/* Result code */
FIL file;				/* File object */
DIR dir;				/* Directory object */
FILINFO fno;			/* File information object */
char *fn;
UINT bw, br;

uint8_t buff[ MAX_TRACK_LEN * 2 ];
uint32_t track_lengs[ (CYL_NUM_MAX+1) * HXCMFM_SD ];
uint32_t track_offsets[ (CYL_NUM_MAX+1) * HXCMFM_SD ];
char Image_File_Name[ MAX_PATH_LEN ];
uint8_t LCDbuff[] = { 0xC2,0x30,0xC3,0x30,0xC7,0x30,0xC9,0x49,0xCB,0x6D };
//                     L1R2 Cyl0 L1R3 Cyl1 L1R7 Side L1R9 IRW  L1R11 mM
char CurrDir[ MAX_PATH_LEN ];
char LastDir[ MAX_PATH_LEN ];
char psLCD[16];
volatile long int CurrBit;
volatile uint32_t CylNumber;
volatile uint32_t LoadedCylNumber;
volatile long int CurrBitW, CurrBitWStart;
volatile long int SideW;
volatile FE_States CurrState = INIT;
volatile FE_States LastState = NONE;
//
MFMIMG *mfmimg;
MFMTRACKIMG *mfmtrackimg;
uint16_t mfm_NOT;				// ����� ���-�� ������ � ����� ( � ������ ������ )
volatile uint16_t mfm_NOC;		// ����� ���-�� ��������� � �����
//
long int TrackListBase;
uint32_t temp_l1, temp_l2;
long int i,j,k;
char * x;
FE_BUTTs ButtonR;
long int AllFiles;
long int FileIndex;
unsigned char fWP;
__IO bool DevWasConfigured = false;
uint32_t TrackNumber;
volatile uint32_t ReqStop, AckStop;
//
//
// Private function prototypes
//
void GPIO_Config(void);
void TIM4_Config(void);
void TIM3_Config(void);
void TIM8_Config(void);
void USART1_Config(void);
void SendChar2USART(char c);
FE_BUTTs WhatKey(void);
long int Load_HXCMFM_file(void);
long int Load_Cylinder(long int);
long int Save_Track(long int);
void Save_Copied_Track( long int );
long int ReadDir(char * DirPath);
static void fault_err (FRESULT rc);
void Error2LCD(unsigned char * ErrorStr);
void WriteStats(void);
static void Delay(__IO uint32_t nCount);
void Prep4FE(void);
void Prep4USBFS(void);
void Prep4COPIER(void);
void Impulse_STEP(void);

void main(void)
{
	SCB->AIRCR = (uint32_t)0x05FA0000 | NVIC_PriorityGroup_4;
	//
	GPIO_Config();
#ifdef TRACE
	xdev_out(SendChar2USART);
	USART1_Config();
	xprintf("\r\nMC has started...\r\n");
#endif
	//
	while (1)
	{
		if ( LastState != CurrState )
		{
			LastState = CurrState;
#ifdef TRACE
	xprintf( "St%d\r\n", CurrState );
#endif
		}
		WriteStats();
		switch ( CurrState )
		{
			case INIT:
			{
				CurrBit = 0;
				lcd44780_init();
				lcd44780_ClearLCD();
				lcd44780_ShowStr("Floppy Emulator");
				lcd44780_SetLCDPosition(0,1);
				lcd44780_ShowStr(VERSION);
				Delay(50);
				/* mount the filesystem */
				if ( ( ret = f_mount( &filesystem, "/", 1 )) != FR_OK )
					fault_err(ret);
				Delay(10);
				//
				TIM3_Config();
				//
				LoadedCylNumber = 99;
				//
				strcpy( CurrDir, "/" );
				strcpy( LastDir, "" );
				CurrState = ENTERDIR;
				break;
			}
			case ENTERDIR:
			{
				AllFiles = ReadDir( CurrDir );
				FileIndex = 0;
				if ( strlen( LastDir ) > 0 )
					while ( FileIndex < AllFiles )
						if ( strcmp( &buff[ FILE_NAME_LEN * FileIndex ] + 1, LastDir ) == 0 )
							break;
						else
							FileIndex++;
				if ( FileIndex == AllFiles )	FileIndex=0;		// �������������� �������� ?
#ifdef TRACE
				xprintf( "AllFiles=%d, FileIndex=%d, Name=%s\r\n", AllFiles, FileIndex, &buff[ FILE_NAME_LEN * FileIndex ] );
#endif
				lcd44780_SetLCDPosition(0,0);
				lcd44780_ShowStr("Select file     ");
				Delay(50);
				CurrState = SELFILE;
				break;
			}
			case LOADCYL:
			{
				while ( ( LoadedCylNumber = Load_Cylinder( CylNumber ) ) != CylNumber )	;
#ifdef TRACE
	xprintf("LC=%d\r\n",LoadedCylNumber);
#endif
				if ( LoadedCylNumber == CylNumber )	CurrState = IDLE;
				//
				break;
			}
			case IDLE:
			{
				pINDEX->BSRR = FE_INDEX;	// Index high
				pTR00->BSRR = FE_TR00;	// TR00 High
				if ( LoadedCylNumber != CylNumber )	CurrState = LOADCYL;
				else
					if ( ( pDS_M->IDR & ( FE_DS | FE_MOTOR ) ) == 0 )
					{
						if ( pWGATE->IDR & FE_WGATE )
						{
							// TIM8 IT Update enable
							TIM8->DIER |= TIM_DIER_UIE;
							// ��������� ����� ������� TIM8 �� ����� PC6
							GPIOC->CRL = 0x4F444444;	// 50MHz AF_OD
							//
							CurrState = READTR;
							// Enable TIM4 CC1 interrupt only
							TIM4->DIER = TIM_DIER_CC1IE;
							//
							LCDbuff[9] = (uint8_t)('M');
							//
							LCDbuff[7] = (uint8_t)('R');
						}
					}
					else
						if ( ( pBUTTs1->IDR & FE_BUT_EN ) == 0 )
						{
							ReqStop = 1;
							while ( AckStop == 0 )	;
							// TIM3 IT Update disable
							TIM3->DIER &= (uint16_t)~TIM_DIER_UIE;
							//
							Delay(5);
							//
							CurrState = ENTERDIR;
						}
						else
							if ( ( pBUTTs2->IDR & FE_BUT_UM ) == 0 )
						{
							ReqStop = 1;
							while ( AckStop == 0 )	;
							// TIM3 IT Update disable
							TIM3->DIER &= (uint16_t)~TIM_DIER_UIE;
							//
							lcd44780_SetLCDPosition(0,0);
							lcd44780_ShowStr("Real disk COPIER");
							lcd44780_SetLCDPosition(0,1);
							lcd44780_ShowStr("Takes real FDD  ");
							Delay(75);
							//
							CurrState = COPIER;
						}
				break;
			}
			case READTR:
			{
				if ( pDS_M->IDR & ( FE_DS | FE_MOTOR ) )
				{
					// ��������� ����� ������� TIM8 �� ����� PC6
					GPIOC->CRL = 0x47444444;	// 50MHz OD
					// TIM8 IT Update disable
					TIM8->DIER &= (uint16_t)~TIM_DIER_UIE;
					//
					CurrState = IDLE;
					// Disable TIM4 interrupts
					TIM4->DIER = 0;
					//
					LCDbuff[9] = (uint8_t)('m');
					//
					LCDbuff[7] = (uint8_t)('I');
				}
				else
					if ( LoadedCylNumber != CylNumber )
					{
						// ��������� ����� ������� TIM8 �� ����� PC6
						GPIOC->CRL = 0x47444444;	// 50MHz OD
						// TIM8 4 us period
						TIM8->ARR = 15;
						//
						CurrState = LOADCYL;
					}
				break;
			}
			case SELFILE:
			{
				lcd44780_SetLCDPosition(0,0);
				lcd44780_ShowStr("                ");
				lcd44780_SetLCDPosition(0,1);
				lcd44780_ShowStr("                ");
				lcd44780_SetLCDPosition(0,0);
				x = CurrDir;
				if ( strlen( CurrDir ) > 12 )	x += strlen( CurrDir ) - 12;
				strcpy( psLCD, x );
				if ( AllFiles == 1 && strcmp( CurrDir, "/" ) != 0 )	// ���������� ���������� �����
#ifdef LCD_STD
					lcd44780_ShowStr("Dir is empty   E");
#else
					lcd44780_ShowStr("Dir is empty   \x7E ");
#endif
				else
					if ( AllFiles == 0 && !strcmp( CurrDir, "/" ) )	// �������� ���������� �����
						lcd44780_ShowStr("Disk is empty   ");
					else
					{

						if ( FileIndex == 0 )
#ifdef LCD_STD
							strcat( psLCD, " DE" );
#else
							strcat( psLCD, " \xDA\x7E" );
#endif
						else
							if ( FileIndex + 1 == AllFiles )
#ifdef LCD_STD
								strcat( psLCD, " UE" );
#else
								strcat( psLCD, " \xD9\x7E" );
#endif
							else
#ifdef LCD_STD
								strcat( psLCD, " DUE" );
#else
								strcat( psLCD, " \xDA\xD9\x7E" );
#endif
						lcd44780_ShowStr( psLCD );	// ������� ���. ����������
					}
				lcd44780_SetLCDPosition(0,1);
				lcd44780_ShowStr( "                " );
				lcd44780_SetLCDPosition(0,1);
				lcd44780_ShowStr( &buff[ FILE_NAME_LEN * FileIndex ] );
				ButtonR = WhatKey();
				switch ( ButtonR )
				{
					case BT_UP:
					{
						if ( FileIndex )
						{
							FileIndex--;
							lcd44780_SetLCDPosition(0,1);
							lcd44780_ShowStr( "                " );
							lcd44780_SetLCDPosition(0,1);
							lcd44780_ShowStr( &buff[ FILE_NAME_LEN * FileIndex ] );
						}
						break;
					}
					case BT_ENTER:
					{
						if ( buff[ FILE_NAME_LEN * FileIndex ] == ' ' )	// ����
							if ( strlen( CurrDir ) <= MAX_PATH_LEN - 1 - 12 )
							{
								strcpy( Image_File_Name, CurrDir );
								if ( *( Image_File_Name + strlen( Image_File_Name ) - 1 ) != '/' )	strcat( Image_File_Name, "/" );
								strcpy( LastDir, (char const *)&buff[ FILE_NAME_LEN * FileIndex + 1 ] );
								strcat( Image_File_Name, (char const *)&buff[ FILE_NAME_LEN * FileIndex + 1 ] );
								if ( Load_HXCMFM_file() == 0 )
								{
									lcd44780_SetLCDPosition(0,0);
									lcd44780_ShowStr( "                " );
									lcd44780_SetLCDPosition(0,0);
									x = Image_File_Name + strlen( Image_File_Name );
									for ( i = 1 ; i <= FILE_NAME_LEN && x > Image_File_Name; i++ ) x--;
									lcd44780_ShowStr( (unsigned char *)x );
									lcd44780_SetLCDPosition(14,0);
									if ( fWP )	lcd44780_ShowStr( "R#" );
									else	lcd44780_ShowStr( " #" );
									lcd44780_SetLCDPosition(0,1);
									lcd44780_ShowStr( "C:   S:         " );
									//
									Delay(10);	// ���������� >=1 �� ��� LCD
									//
									Prep4FE();
									//
									ReqStop = 0;
									AckStop = 0;
									// TIM3 IT Update enable
									TIM3->DIER |= TIM_DIER_UIE;
									//
									CylNumber = 0;
									//
									CurrState = LOADCYL;
								}
								else
									CurrState = ENTERDIR;
							}
							else
							{
								Error2LCD( "Path too long  \x7E" );
								break;
							}
						else	// ����������
						{
							if ( buff[ FILE_NAME_LEN * FileIndex ] == '<' )	// �����
							{
								x = CurrDir + strlen( CurrDir );
								while ( *--x != '/' )	;
								strcpy( LastDir, x + 1 );
								if ( x == CurrDir )	x++;
								*x = '\0';
#ifdef TRACE
								xprintf( "CurrDir=%s, LastDir=%s\r\n", CurrDir, LastDir );
#endif
							}
							else	// ����
							{
								if ( *( CurrDir + strlen( CurrDir ) - 1 ) != '/' )	strcat( CurrDir, "/" );
								strcat( CurrDir, (char const *)&buff[ FILE_NAME_LEN * FileIndex + 1 ] );
								strcpy( LastDir, "" );
							}
#ifdef TRACE
							xprintf( "CurrDir=%s\r\n", CurrDir );
#endif
							CurrState = ENTERDIR;
						}
						break;
					}
					case BT_DOWN:
					{
						if ( FileIndex + 1 < AllFiles )
						{
							FileIndex++;
							lcd44780_SetLCDPosition(0,1);
							lcd44780_ShowStr( "                " );
							lcd44780_SetLCDPosition(0,1);
							lcd44780_ShowStr( &buff[ FILE_NAME_LEN * FileIndex ] );
						}
						break;
					}
					case BT_USBMode:
					{
						lcd44780_SetLCDPosition(0,0);
						lcd44780_ShowStr("USB PC Link mode");
						lcd44780_SetLCDPosition(0,1);
						lcd44780_ShowStr("Connect USB plug");
						Delay(75);
						CurrState = USBMODE;
						break;
					}
				}
				break;
			}
			case WRITETR:
			{
				if ( pWGATE->IDR & FE_WGATE )
				{
					// Enable EXTI Line13 (step)
//					EXTI->IMR |= EXTI_Line13;
					//
					temp_l2 = CurrBitWStart;
					temp_l1 = ( CurrBitW + 1 - temp_l2 ) >> 3;
#ifdef TRACE
xprintf("\r\nStart=%d Length=%d, SideW=%d\r\n",temp_l2,temp_l1,SideW);
//for (i=0;i<32;i++) xprintf("%X ",buff[i+SideW]);
//xprintf("\r\n");
//for (i=0;i<32;i++) xprintf("%X ",buff[i+12800]);
//xprintf("\r\n");
#endif
//					if ( ( temp_l1 > CurrTrackLength ) || ( temp_l2 == 0 ) )
//					{
//						CurrTrackLength = temp_l1;
//						track_lengs[ ( LoadedCylNumber << 1 ) + ( SideW > 0 ) ] = temp_l1;
//					}
					// ��������� ����� ������� TIM8 �� ����� PC6
					GPIOC->CRL = 0x4F444444;	// 50MHz AF_OD
					//
					Save_Track( LoadedCylNumber );
					//
					CurrState = READTR;
					//
					LCDbuff[15] = (uint8_t)('R');
				}
				break;
			}
			case COPIER:
			{
				// ����������
				Prep4COPIER();
				// ����� ���������� ���������
				lcd44780_SetLCDPosition(0,0);
				lcd44780_ShowStr("Insert disk B:  ");
				lcd44780_SetLCDPosition(0,1);
				lcd44780_ShowStr("ENTER to start  ");
				while ( WhatKey() != BT_ENTER )	;
				//
				lcd44780_SetLCDPosition(0,0);
				lcd44780_ShowStr("Copying started");
				lcd44780_SetLCDPosition(0,1);
				lcd44780_ShowStr("Wait for reset  ");
				// ��������, �������� �� ���� SHUGART
				i = 0;
				while  ( i == 0 )
				{
					if ( ( pINDEX->IDR & FE_INDEX ) && \
						( pSIDE->IDR & FE_SIDE ) && \
						( pDIR->IDR & FE_DIR ) && \
						( pDS_M->IDR & FE_DS ) && \
						( pDSOUT->IDR & FE_DSOUT ) && \
						( pSTEP->IDR & FE_STEP ) && \
						( pMOTOR->IDR & FE_MOTOR ) )	i = 1;
					else
					{
						i = 0;
						lcd44780_SetLCDPosition(0,0);
						lcd44780_ShowStr("FDD bus is BUSY ");
						lcd44780_SetLCDPosition(0,1);
						lcd44780_ShowStr("(ENTER to reset)");
						if ( ( pBUTTs1->IDR & FE_BUT_EN ) == 0 )	NVIC_SystemReset();
					}
				}
				// DRV1_SEL active
				pDSOUT->BRR = FE_DSOUT;
#ifdef TRACE
	xprintf("Drv_Sel_1 active\r\n");
	xprintf("TR00=%d\r\n", pTR00->IDR & FE_TR00 );
	if ( ( pDIR->IDR & FE_DIR ) == 0 )
	{
		xprintf("\r\nDIR is low\r\n");
		while (1)	;
	}
#endif
				// ����� ������� �������
				if ( pTR00->IDR & FE_TR00 )
				{
					pDIR->BSRR = FE_DIR;
					i = CYL_NUM_MAX;	// 85 tracks maximum there are
					while ( pTR00->IDR & FE_TR00 && i-- >= 0 )	Impulse_STEP();
					if ( i < 0 )
					{
						lcd44780_SetLCDPosition(0,0);
						lcd44780_ShowStr("TR00 not reached");
						lcd44780_SetLCDPosition(0,1);
						lcd44780_ShowStr("ENTER to reset  ");
						while ( WhatKey() != BT_ENTER )	;
						NVIC_SystemReset();
					}
				}
				// ����������� � ������ ����� (79 �������)
				pDIR->BRR = FE_DIR;
				// �������� �����
				pMOTOR->BRR = FE_MOTOR;
				// ����, ���� �� ��������������� ��������
				Delay(20);
				//
				for ( TrackNumber = 0; TrackNumber < mfm_NOT; TrackNumber++ )
				{
#ifdef TRACE
	xprintf("TrackNumber=%d\r\n",TrackNumber);
#endif
					if ( TrackNumber & 1 )
						pSIDE->BRR = FE_SIDE;
					else
						pSIDE->BSRR = FE_SIDE;
					// ���� ����� INDEX
					while ( ( pINDEX->IDR & FE_INDEX ) == 0 )	;	//  ���� ������ 0, �� ���� ������� 1
					while ( pINDEX->IDR & FE_INDEX )	;	//	������ 1, ���� 0 (����)
					// ������������� ������ 8
					TIM8 -> CNT = 0;							// �������� ������� �������� ��������
					TIM8 -> EGR = TIM_EGR_UG | TIM_EGR_CC1G;		// ���������� ������� ����������
					//
					CurrBitW = 0;
					// Enable TIM8 CC1 interrupt
					TIM8->DIER = TIM_DIER_CC1IE;
					// ���� ����� �����
					while ( ( pINDEX->IDR & FE_INDEX ) == 0 )	;	//  ���� ������ 0, �� ���� ������� 1
					while ( pINDEX->IDR & FE_INDEX )	;	//	������ 1, ���� 0 (����)
					// ������������� ������ 8
					TIM8->DIER = 0;
					Delay(1);
					// ���������� � ������� ����� �����
					track_lengs[ TrackNumber ] = ( CurrBitW + 1 ) >> 3;
					// ������ � ���� �����
#ifdef TRACE
xprintf("Length[%d] = %d\r\n", TrackNumber, track_lengs[ TrackNumber ] );
for ( i = 0; i < 64; i++ )	xprintf( "%X ", buff[i] );
xprintf("\r\n");
#endif
				Save_Copied_Track( TrackNumber );
					// ���� ���� �������� � �� ���������, ���� ������� STEP
					if ( TrackNumber & 1 && TrackNumber < mfmimg->number_of_track * mfmimg->number_of_side - 1 )	Impulse_STEP();
				}
				// ��������� ��� �������
				pSIDE->BSRR = FE_SIDE;
				pDIR->BSRR = FE_DIR;
				pSIDE->BSRR = FE_STEP;
				// ��������� ������ ��������
				pMOTOR->BSRR = FE_MOTOR;
				// DRV1_SEL inactive
				pDSOUT->BSRR = FE_DSOUT;
				//
				NVIC_SystemReset();
				break;
			}
			case USBMODE:
			{
				lcd44780_SetLCDPosition(0,0);
				lcd44780_ShowStr("Auto reset after");
				lcd44780_SetLCDPosition(0,1);
				lcd44780_ShowStr("PC disconnected ");
				Prep4USBFS();
				Set_System();
				Set_USBClock();
				USB_Interrupts_Config();
				USB_Init();
				while ( bDeviceState != CONFIGURED )	;
				DevWasConfigured = true;
				while ( 1 )	;
				break;
			}
		}
	}
}

long int Load_Cylinder( long int Cyl_Number )
{
	ret = f_open( &file, Image_File_Name, FA_READ );
	if (ret)	fault_err(ret);
	//
	ret = f_lseek( &file, track_offsets[ Cyl_Number << 1 ] );
	if (ret)	fault_err(ret);
	//
	ret = f_read( &file, buff, MAX_TRACK_LEN, &br );
	if (ret)	fault_err(ret);
	//
	ret = f_lseek( &file, track_offsets[ 1 + ( Cyl_Number << 1 ) ] );
	if (ret)	fault_err(ret);
	//
	ret = f_read( &file, buff + MAX_TRACK_LEN, MAX_TRACK_LEN, &br );
	if (ret)	fault_err(ret);
	//
	ret = f_close( &file );
	if (ret)	fault_err(ret);
	// Cylinder
	LCDbuff[1] = 0x30 + (uint8_t)( Cyl_Number / 10 );
	LCDbuff[3] = 0x30 + (uint8_t)( Cyl_Number % 10 );
	//
	return Cyl_Number;
}

long int Save_Track( long int Cyl_Number )
{
	ret = f_open(&file, Image_File_Name, FA_WRITE);
	if (ret)	fault_err(ret);
	//
	ret = f_lseek(&file, track_offsets[ ( Cyl_Number << 1 ) + ( SideW > 0 ) ]);
	if (ret)	fault_err(ret);
	//
	ret = f_write(&file, buff + SideW, MAX_TRACK_LEN, &bw);

#ifdef TRACE
	xprintf("written=%d, ret=%d\r\n", bw, ret );
#endif

	if (ret)	fault_err(ret);
	//
//	ret = f_lseek(&file, TrackListBase + sizeof(MFMTRACKIMG) * ( ( Cyl_Number << 1 ) + ( SideW > 0 ) ) + \
//					(offsetof(MFMTRACKIMG, mfmtracksize) - offsetof(MFMTRACKIMG, track_number)) );
//	if (ret)	fault_err(ret);
//	//
//	ret = f_write(&file, (void *)&track_lengs[ ( LoadedCylNumber << 1 ) + ( SideW > 0 ) ] , 4, &bw);
//	if (ret)	fault_err(ret);
	//
	ret = f_close(&file);
	if (ret)	fault_err(ret);
	//
	return Cyl_Number;
}

void Save_Copied_Track( long int Copied_Track_Number )
{
	ret = f_open(&file, Image_File_Name, FA_WRITE);
	if (ret)	fault_err(ret);
	//
	ret = f_lseek( &file, track_offsets[ Copied_Track_Number ] );
	if (ret)	fault_err(ret);
	//
	ret = f_write( &file, buff, MAX_TRACK_LEN, &bw );

#ifdef TRACE
	xprintf("writtenCT=%d, ret=%d\r\n", bw, ret );
#endif

	if (ret)	fault_err(ret);
	//
	ret = f_lseek(&file, TrackListBase + sizeof(MFMTRACKIMG) * Copied_Track_Number + \
					(offsetof(MFMTRACKIMG, mfmtracksize) - offsetof(MFMTRACKIMG, track_number)) );
	if (ret)	fault_err(ret);
	//
	ret = f_write( &file, (void *)&track_lengs[ Copied_Track_Number ], 4, &bw );
	if (ret)	fault_err(ret);
	//
#ifdef TRACE
	xprintf("writtenCTL=%d, ret=%d\r\n", bw, ret );
#endif
	//
	ret = f_close(&file);
	if (ret)	fault_err(ret);
}

long int Load_HXCMFM_file(void)
{
	ret = f_stat( Image_File_Name, &fno );
	if (ret)	return -1L;
	// ���� ���� Read-Only, �� ������ WP=0
	if ( fWP = fno.fattrib & AM_RDO )	// fWP=1 -> WP=0
		pWP->BRR = FE_WP;	// WP=0
	else
		pWP->BSRR = FE_WP;	// WP=1
	//
	ret = f_open(&file, Image_File_Name, FA_READ);
	if (ret)	fault_err(ret);
	//
	ret = f_read(&file, buff, 0x800, &br);	// 0x800 - ��������� + ������� �������� ������
	if (ret)	fault_err(ret);
	//
	ret = f_close(&file);
	if (ret)	fault_err(ret);
	//
	mfmimg = (MFMIMG *)buff;
	//
	if ( strcmp( "HXCMFM", (char const *)mfmimg->headername ) )
	{
		Error2LCD("Wrong header");
		return -1;
	}
	if ( mfmimg->number_of_track > (CYL_NUM_MAX+1) )
	{
		Error2LCD("Tracks > MAX");
		return -1;
	}
	if ( mfmimg->number_of_side > HXCMFM_SD || mfmimg->number_of_side < 1 )
	{
		Error2LCD("Sides 2 or 1");
		return -1;
	}
	if ( mfmimg->floppyRPM != HXCMFM_RPM )
	{
		Error2LCD("Not 300 RPM");
		return -1;
	}
	if ( mfmimg->floppyBitRate != HXCMFM_BR )
	{
		Error2LCD("Not 250 kbs");
		return -1;
	}
//	if ( mfmimg->floppyiftype != HXCMFM_FT )
//	{
//		Error2LCD("Not TR-DOS");
//		return -1;
//	}
	//
	mfm_NOT = mfmimg->number_of_track * mfmimg->number_of_side;
	mfm_NOC = mfmimg->number_of_track;
	//
	mfmtrackimg = (MFMTRACKIMG *)(buff + mfmimg->mfmtracklistoffset);
	TrackListBase = mfmimg->mfmtracklistoffset;
	//
	for ( i = 0; i < mfm_NOT; i++ )
	{
		track_lengs[i] = mfmtrackimg->mfmtracksize;
		track_offsets[i] = mfmtrackimg->mfmtrackoffset;
		mfmtrackimg++;
	}
	//
	return 0;
}

// ��������� ����� ������ � ������������� � ������,
// ��� ���� ����������� ������ ������ " ",
// ���� ��� ����, ��� "*", ���� ��� �������������
// ���������� ���-�� ������ � �������������
// �����! ffconf.h : #define _FS_RPATH 0
long int ReadDir( char * DirPath )
{
#ifdef TRACE
	xprintf("\r\n--- Directory %s ---\r\n", DirPath );
#endif
	ret = f_opendir( &dir, DirPath );	// Open a directory
	if (ret)	fault_err(ret);
	//
	if ( strcmp( DirPath, "/" ) != 0 )	// Non-root directory must contain "<UP-DIR>"
	{
		strcpy( &buff[ FILE_NAME_LEN * 0 ], "<UP-DIR>" );
		i = 1;
#ifdef TRACE
		xprintf("%s\r\n", &buff[ FILE_NAME_LEN * 0 ] );
#endif
	}
	else
		i = 0;
	for ( ; i < ( MAX_TRACK_LEN * 2 / FILE_NAME_LEN ); i++ )
	{
		ret = f_readdir( &dir, &fno );	// Read a directory item
		if ( ret != FR_OK || fno.fname[0] == 0 ) break;  // Break on error or end of dir
		fn = fno.fname;
#ifdef TRACE
		xprintf("%s\r\n", fn );
#endif
//
//	����� �������� ����� ? 8.3
//
		strcpy( &buff[ FILE_NAME_LEN * i + 1 ], fn );
		if ( fno.fattrib & AM_DIR )		// Is a directory
			buff[ FILE_NAME_LEN * i ] = '*';
		else
			buff[ FILE_NAME_LEN * i ] = ' ';
	}
	f_closedir( &dir );
#ifdef TRACE
	xprintf("AllFiles = %d\r\n", i );
#endif
	return i;
}

FE_BUTTs WhatKey(void)
{
	uint16_t uPortAC;

	while (1)
	{
		uPortAC = ( pBUTTs1->IDR & ( FE_BUT_UP | FE_BUT_EN ) ) | \
			( pBUTTs2->IDR & ( FE_BUT_DN | FE_BUT_UM ) );
		Delay( 20 );
		if ( ( uPortAC & FE_BUT_UP ) == 0 )
			return BT_UP;
		else
			if ( ( uPortAC & FE_BUT_DN ) == 0 )
				return BT_DOWN;
			else
				if ( ( uPortAC & FE_BUT_EN ) == 0 )
					return BT_ENTER;
				else
					if ( ( uPortAC & FE_BUT_UM ) == 0 )
						return BT_USBMode;
	}
}

void Error2LCD(unsigned char * ErrorStr)
{
	lcd44780_ClearLCD();
	lcd44780_SetLCDPosition(0,0);
	lcd44780_ShowStr( "E:" );
	lcd44780_SetLCDPosition(2,0);
	lcd44780_ShowStr( ErrorStr );
	lcd44780_SetLCDPosition(0,1);
	lcd44780_ShowStr( "- Push any key -" );
	WhatKey();
}

void WriteStats(void)
{
	if ( CurrState <= SELFILE )
	{
		// Side
		if ( pSIDE->IDR & FE_SIDE )
			LCDbuff[5] = (uint8_t)('0');
		else
			LCDbuff[5] = (uint8_t)('1');
	}
}

static void fault_err (FRESULT rc)
{
	const char *str =
					"OK\0" "DISK_ERR\0" "INT_ERR\0" "NOT_READY\0" "NO_FILE\0" "NO_PATH\0"
					"INVALID_NAME\0" "DENIED\0" "EXIST\0" "INVALID_OBJECT\0" "WRITE_PROTECTED\0"
					"INVALID_DRIVE\0" "NOT_ENABLED\0" "NO_FILE_SYSTEM\0" "MKFS_ABORTED\0" "TIMEOUT\0"
					"LOCKED\0" "NOT_ENOUGH_CORE\0" "TOO_MANY_OPEN_FILES\0";
	FRESULT i;

	for (i = (FRESULT)0; i != rc && *str; i++)
	{
		while (*str++) ;
	}
	lcd44780_ClearLCD();
	lcd44780_ShowStr("Error:");
	lcd44780_SetLCDPosition(0,1);
	lcd44780_ShowStr( (unsigned char *)str );
#ifdef ERROR_RESET
	Delay(75);
	NVIC_SystemReset();
#else
	while(1)	;
#endif
}

void GPIO_Config(void)
{
	/*Enable the APB2 peripheral clock */
	RCC->APB2ENR |= RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOB | \
					RCC_APB2Periph_GPIOC | RCC_APB2Periph_GPIOD | \
					RCC_APB2Periph_GPIOE | RCC_APB2Periph_AFIO;
	// PA8: USB_PullUP (INPUT); PA9:USART_TX; PA11,12:USB�� ���������� ����
	GPIOA->CRH = 0x444444B4;	//	50MHz,AF_PP
	// PB14,15:BUTTONs INPUT
	GPIOB->CRH = 0x44444444;	// INPUT
	// PC8-12:SDIO
	GPIOC->CRH = 0x444BBBBB;	// 50MHz,AF_PP
	// PD0 SD_DETECT INPUT; PD2 SDIO_CMD
	GPIOD->CRL = 0x44444B44;	// 50MHz,AF_PP
	// PD10-15:LCD
	GPIOD->CRH = 0x66666644;	// 2MHz,OD
}

void TIM8_Config(void)
{
	// Enable the TIM8 global Interrupt
	NVIC->IP[ TIM8_UP_IRQn ] = 0;	// NVIC_IRQChannelPreemptionPriority = 0
	NVIC->ISER[ TIM8_UP_IRQn >> 5 ] = 1 << ( TIM8_UP_IRQn & 0x1F);	// NVIC_IRQChannelCmd = ENABLE
	// TIM8 clock enable
	RCC->APB2ENR |= RCC_APB2Periph_TIM8;
	TIM8->CCER = 0;	// ������ ������
	TIM8->ARR = 15;	// ������ ���������
	TIM8->PSC = 17;	// ������������ 18
	TIM8->CCR1 = 4;	// ������������ ���������
	TIM8->CCMR1 |= TIM_CCMR1_OC1M_1 | TIM_CCMR1_OC1M_2 | TIM_CCMR1_OC1PE;	// �������� ����� ��� 1, Preload enable
	TIM8->CCER |= TIM_CCER_CC1E | TIM_CCER_CC1P;	// ��������� ����� ���������������� �������
//	TIM8->CR1 &= (uint16_t)~TIM_CR1_ARPE;	// ARR preload disable
	TIM8->CR1 |= TIM_CR1_ARPE;	// ARR Preload+
	TIM8->CR2 |= TIM_CR2_CCPC;	// OC Preload+
	TIM8->BDTR |= TIM_BDTR_MOE;	// Main output enable
	TIM8->CR1 |= TIM_CR1_CEN;	// ��������� ����
}

void TIM4_Config(void)
{
	// Enable the TIM4 global Interrupt
	NVIC->IP[ TIM4_IRQn ] = 0;	// NVIC_IRQChannelPreemptionPriority = 0
	NVIC->ISER[ TIM4_IRQn >> 5 ] = 1 << ( TIM4_IRQn & 0x1F);	// NVIC_IRQChannelCmd = ENABLE
	// TIM4 clock enable
	RCC->APB1ENR |= RCC_APB1Periph_TIM4;
	TIM4->ARR = 0xffff;	// ������ ���������
	TIM4->PSC = 4;	// ������������ 5
//	TIM4->CR1 &= (uint16_t)~TIM_CR1_CKD;	// Clock division=0 After reset
	TIM4->CR1 = TIM_CR1_ARPE;	// ARR preload enable
//	TIM4->CCER = 0;	// After reset
	TIM4->CCMR1 = TIM_CCMR1_CC1S_0;	// No filter, no prescaler, CC1 input IC1<-TI1
	// Select the TIM4 Input Trigger: TI1FP, Slave Mode: Reset Mode
	TIM4->SMCR = TIM_TS_TI1FP1 | TIM_SlaveMode_Reset | TIM_MasterSlaveMode_Enable;
	// ��������� ���������
	TIM4->CCER = TIM_CCER_CC1E;
	// Enable the TIM4 Counter
	TIM4->CR1 |= TIM_CR1_CEN;
//	// Enable TIM4 CC1 interrupt
//	TIM4->DIER = TIM_DIER_CC1IE;
}

void TIM3_Config(void)
{
	// Enable the TIM3 global Interrupt
	NVIC->IP[ TIM3_IRQn ] = 0x0F << 0x04;	// NVIC_IRQChannelPreemptionPriority = 0x0F
	NVIC->ISER[ TIM3_IRQn >> 5 ] = 1 << ( TIM3_IRQn & 0x1F);	// NVIC_IRQChannelCmd = ENABLE
	// TIM3 clock enable
	RCC->APB1ENR |= RCC_APB1Periph_TIM3;
	TIM3->ARR = 1439;			// ������ ���������
	TIM3->PSC = 0;				// ������������ 1
	TIM3->CR1 |= TIM_CR1_ARPE;	// ARR Preload+
	TIM3->CR1 |= TIM_CR1_CEN;	// ��������� ����
}

void USART1_Config(void)
{
	RCC->APB2ENR |= RCC_APB2Periph_USART1 | RCC_APB2ENR_AFIOEN;
	USART1->BRR = 0x271;	// 115200
	USART1->CR1 |= USART_CR1_UE | USART_CR1_TE;
}

void SendChar2USART(char c)
{
	while ( ( USART1->SR & USART_SR_TXE ) == 0 )	;
	USART1->DR = (uint8_t) c;
}

static void Delay(__IO uint32_t nCount)
{
	__IO uint32_t index;


	for (index = (100000 * nCount); index != 0; index--);
}

void Prep4FE(void)
{
	pINDEX->BSRR = FE_INDEX;	// Index high
	pTR00->BSRR = FE_TR00;		// TR00 high
	pWP->BSRR = FE_WP;			// WP high
	//
	GPIOA->CRL = 0x44444444;
	// PA8: USB_PullUP (INPUT); PA9:USART_TX; PA11,12:USB�� ���������� ����
//	GPIOA->CRH = 0x444444B4;	//	50MHz,AF_PP
	// PB6:TIM4 CH1 INPUT
	GPIOB->CRL = 0x44444444;
	// PB10:WP; PB11:SIDE INPUT; PB12:READY; PB14,15:BUTTONs INPUT
//	GPIOB->CRH = 0x44464644;	// 2MHz,OD; INPUT
	// PC6:TIM8 CH1 OUTPUT
	GPIOC->CRL = 0x4F444444;	// 50MHz,AF_OD	- ������ ��� ������ OD!!!
	GPIOC->BSRR = GPIO_Pin_6;
	// PC8-12:SDIO
//	GPIOC->CRH = 0x444BBBBB;	// 50MHz,AF_PP
	// PD0 SD_DETECT INPUT; PD2 SDIO_CMD
//	GPIOD->CRL = 0x44444B44;	// 50MHz,AF_PP
	// PD10-15:LCD
//	GPIOD->CRH = 0x66666644;	// 2MHz,OD
	// PE7:DENSITY
	GPIOE->CRL = 0x64444444;	// 2MHz,OD
	// PE8:DSout; PE10:INDEX; PE15:TR00
	GPIOE->CRH = 0x74444744;	// 50MHz,OD
	//
	TIM8_Config();
	TIM4_Config();
	//
	NVIC->IP[ EXTI15_10_IRQn ] = 0;	// NVIC_IRQChannelPreemptionPriority = 0
	NVIC->ISER[ EXTI15_10_IRQn >> 5 ] = 1 << ( EXTI15_10_IRQn & 0x1F);	// NVIC_IRQChannelCmd = ENABLE
	// Enable AFIO (port signal selector)
	RCC->APB2ENR |= RCC_APB2Periph_AFIO;
	// Connect EXTI Line13 to PE13 pin
	AFIO->EXTICR[ GPIO_PinSource13 >> 2 ] |= (((uint32_t)GPIO_PortSourceGPIOE) << \
		(0x04 * (GPIO_PinSource13 & (uint8_t)0x03)));
	// Connect EXTI Line14 to PE14 pin
	AFIO->EXTICR[ GPIO_PinSource14 >> 2 ] |= (((uint32_t)GPIO_PortSourceGPIOE) << \
		(0x04 * (GPIO_PinSource14 & (uint8_t)0x03)));
	// Enable EXTI Line13,14
	EXTI->IMR |= EXTI_Line13 | EXTI_Line14;
	// Select Rising trigger for EXTI Line 13
	EXTI->RTSR |= EXTI_Line13;
	// Select Falling trigger for EXTI Line 14
	EXTI->FTSR |= EXTI_Line14;
}

void Prep4USBFS(void)
{
	//	Disable all the interrupts
	TIM4->DIER = 0;
	TIM8->DIER = 0;
	TIM3->DIER = 0;
	// Disable EXTI Line13,14
	EXTI->IMR &= EXTI_Line13 | EXTI_Line14;
}

void Prep4COPIER(void)
{
	//
	TIM4->DIER = 0;
	TIM8->DIER = 0;
	TIM3->DIER = 0;
	Delay(1);
	// ������ ��������������
	// PB10:WP; PB11:SIDE; PB12:READY; PB14,15:BUTTONs INPUT
	pSIDE->BSRR = FE_SIDE;		// PB11
	GPIOB->CRH = 0x44447444;	// INPUT
	// PC6:TIM8 CH1 INPUT
	GPIOC->CRL = 0x44444444;	// INPUT
	GPIOC->BRR = GPIO_Pin_6;
	// PE7:DENSITY
	GPIOE->CRL = 0x44444444;	// INPUT
	// PE8:DSout; PE10:INDEX; PE15:TR00
	pDIR->BSRR = FE_DIR;		// PE8,11-13
	pDS_M->BSRR = FE_DS;
	pSTEP->BSRR = FE_STEP;
	pMOTOR->BSRR = FE_MOTOR;
	pDSOUT->BSRR = FE_DSOUT;
	GPIOE->CRH = 0x44777447;	// 50MHz,OD; INPUT
	// Enable the TIM8 global Interrupt
	NVIC->IP[ TIM8_CC_IRQn ] = 0;	// NVIC_IRQChannelPreemptionPriority = 0
	NVIC->ISER[ TIM8_CC_IRQn >> 5 ] = 1 << ( TIM8_CC_IRQn & 0x1F);	// NVIC_IRQChannelCmd = ENABLE
	// TIM8 ������������������� �� ����
	TIM8->CCER = 0;
	TIM8->CR1 = 0;	// Clock disable
	TIM8->CR1 = TIM_CR1_ARPE;	// ARR preload enable
	TIM8->BDTR = 0;	// Main output disable
	TIM8->CR2 = 0;
	// ���������� ������� ����������
//	TIM8->EGR = TIM_EGR_UG | TIM_EGR_CC1G;
	TIM8->ARR = 0xffff;	// ������ ���������
	TIM8->PSC = 4;	// ������������ 5
	TIM8->CCMR1 = TIM_CCMR1_CC1S_0;	// No filter, no prescaler, CC1 input IC1<-TI1
	// Select the TIM8 Input Trigger: TI1FP, Slave Mode: Reset Mode
	TIM8->SMCR = TIM_TS_TI1FP1 | TIM_SlaveMode_Reset | TIM_MasterSlaveMode_Enable;
	// ��������� ���������
	TIM8->CCER = TIM_CCER_CC1E;
	// Enable the TIM8 Counter
	TIM8->CR1 |= TIM_CR1_CEN;
	// Disable EXTI Line13,14
	EXTI->IMR &= EXTI_Line13 | EXTI_Line14;
}

void Impulse_STEP(void)
{
	__IO uint32_t index0;


	pSTEP->BRR = FE_STEP;
	for ( index0 = 0; index0 < 4; index0++ )	;	// ~1 ���
	pSTEP->BSRR = FE_STEP;
	Delay(1);	// ~17 ��
#ifdef TRACE
	xprintf(" STEP\r\n");
#endif
}

#ifdef USE_FULL_ASSERT
void assert_failed(uint8_t* file, uint32_t line)
{
  while (1)	;
}
#endif
