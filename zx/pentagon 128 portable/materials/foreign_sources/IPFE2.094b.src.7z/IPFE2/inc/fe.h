/* IPFE Floppy Emulator 2014-2015 IanPo(zx-pk.ru) */

#ifndef __FE_H
#define __FE_H

#define FE_DENSITY	((uint16_t) 1<<7 )	// PE7
#define FE_READY	((uint16_t) 1<<12 )	// PB12
#define FE_INDEX	((uint16_t) 1<<10 )	// PE10
#define FE_TR00		((uint16_t) 1<<15 )	// PE15
#define FE_WP		((uint16_t) 1<<10 )	// PB10
#define FE_DSOUT	((uint16_t) 1<<8 )	// PE8
//
#define FE_DS		((uint16_t) 1<<9 )	// PE9
#define FE_MOTOR	((uint16_t) 1<<11 )  // PE11
#define FE_DIR		((uint16_t) 1<<12 )  // PE12
#define FE_STEP		((uint16_t) 1<<13 )  // PE13
#define FE_WGATE	((uint16_t) 1<<14 )  // PE14
#define FE_SIDE		((uint16_t) 1<<11 )  // PB11

#define pDENSITY	GPIOE
#define pREADY		GPIOB
#define pINDEX		GPIOE
#define pTR00		GPIOE
#define pWP			GPIOB
#define	pDSOUT		GPIOE
#define	pDS_M		GPIOE
#define	pWGATE		GPIOE
#define	pSIDE		GPIOB
#define	pDIR		GPIOE
#define	pSTEP		GPIOE
#define	pMOTOR		GPIOE

#define FE_BUT_UP	((uint16_t) 1<<8 )  // PD8
#define FE_BUT_DN	((uint16_t) 1<<14 )  // PB14
#define FE_BUT_EN	((uint16_t) 1<<9 )  // PD9
#define FE_BUT_UM	((uint16_t) 1<<15 )  // PB15
#define pBUTTs1		GPIOD				// UP, EN
#define pBUTTs2		GPIOB				// DN, UM

#define	MAX_TRACK_LEN	12800	// bytes

#define CYL_NUM_MAX	84

//#define HXCMFM_NOT	80
#define HXCMFM_SD	2
#define HXCMFM_RPM	0x0000
#define HXCMFM_BR	0x00FA
#define HXCMFM_FT	7

#define INDEX_START	0
#define INDEX_STOP	INDEX_START + 64 * 2

#define MAX_PATH_LEN	64

#define FILE_NAME_LEN	14
// 1 ������{d,f} + �����{8.3} + 1 ����������� 0 = 14

#pragma pack(1)

typedef struct
{
	unsigned char headername[7];
	unsigned short number_of_track;
	unsigned char number_of_side;
	unsigned short floppyRPM;
	unsigned short floppyBitRate;
	unsigned char floppyiftype;
	unsigned long mfmtracklistoffset;
} MFMIMG;	// 19 ����

typedef struct
{
	unsigned short track_number;
	unsigned char side_number;
	unsigned long mfmtracksize;
	unsigned long mfmtrackoffset;
} MFMTRACKIMG;	// 11 ���� * number_of_track * number_of_side

#pragma pack()

typedef enum { NOWT, BT_UP, BT_ENTER, BT_DOWN, BT_USBMode } FE_BUTTs;
typedef enum { INIT, LOADCYL, IDLE, READTR, WRITETR, SELFILE, ENTERDIR, USBMODE, COPIER, NONE } FE_States;

#endif	/* FE_H */
